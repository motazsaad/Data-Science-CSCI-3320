library(tidyverse)
library(ggplot2)
library(lubridate)
library(dplyr)
library(readr)
library(tidyr)

Jan <-read.csv('January.csv')
Feb <-read.csv('February.csv')
Mar <-read.csv('March.csv')
Apr <-read.csv('April.csv')
May <-read.csv('May.csv')
Jun <-read.csv('June.csv')
Jul <-read.csv('July.csv')
Aug <-read.csv('August.csv')
Sep <-read.csv('September.csv')
Oct <-read.csv('October.csv')
Nov <-read.csv('November.csv')
Dec <-read.csv('December.csv')

View(Nov)
colnames(Nov)
summary(Nov)


complete_data <- bind_rows(Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec)
head(complete_data)
colnames(complete_data)
str(complete_data)
###DATA VISUALIZATION

#the data seems to indicate that those owning a membership use bikes to go to work as opposed to casual users

complete_data %>% 
  group_by(member_casual, day_of_week) %>% 
  summarise(total = n()) %>% 
  
  ggplot(aes(x = day_of_week, y = total, fill = member_casual)) + 
  geom_col(position= "dodge") + 
  labs(x='Day of Week', y='Total Number of Rides', title='Rides per Day of Week', fill = 'subs') + 
  scale_y_continuous(breaks = c(0, 250000, 500000), labels = c("0", "250K", "500K"))+ 
  scale_x_continuous(breaks = c(1,2,3,4,5,6,7), labels= c("Sun", "Mon", "Tue","Wed", "Thu", "Fri", "Sat" )) +
  geom_line(aes(color= member_casual))

#evidence of membership used by people who commute to work 
complete_data %>% 
  group_by(start_hour, member_casual) %>% 
  summarise(total = n()) %>% 
  
  ggplot(aes(x = start_hour , y = total, fill = member_casual))+
  geom_col(position = "dodge")+
  scale_y_continuous(breaks = c(0, 100000, 200000, 300000), labels = c("0", "100K", "200K", "300K"))+ 
  scale_x_continuous(breaks = c(0,3,6,9,12,15,18,21,24), labels= c("0:00", "3:00", "6:00","9:00", "12:00", "15:00", "18:00", "21:00", "24:00" ))


#investigating the trends in months, it seems that casual users peak in summer
complete_data %>% 
  group_by(member_casual, month) %>% 
  summarise(total = n()) %>% 
  
  ggplot(aes(x = month, y = total, fill = member_casual)) + 
  geom_col(position= "dodge") + 
  labs(x='Month', y='Total Number of Rides', title='Rides per Month', fill = 'subs') + 
  scale_y_continuous(breaks = c(0, 250000, 400000), labels = c("0", "250K", "400K")) +
  scale_x_continuous(breaks = c(1,2,3,4,5,6,7,8,9,10,11,12), labels= c("Jan", "Feb", "Mar","Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov","Dec" ))

#this chart confirms our findings suggestion to create a summer membership 
complete_data %>% 
  group_by(member_casual, season) %>% 
  summarise(total = n()) %>% 
  ggplot(aes(x = season, y = total, fill = member_casual)) + 
  geom_col(position= "dodge") + 
  labs(x='Season', y='Total Number of Rides', title='Season trends', fill = 'subs') + 
  scale_y_continuous(breaks = c(0, 500000, 1000000), labels = c("0", "500K", "1M")) +
  scale_x_continuous(breaks = c(1,2,3,4), labels= c("Spring", "Summer", "Autumn","Winter"))

#average
complete_data %>% 
  group_by(member_casual, day_of_week) %>% 
  summarise(total = n(), average = mean(minutes)) %>% 
  ggplot(aes(x = day_of_week, y = average, fill = member_casual)) +geom_col(position = "dodge")

complete_data %>% 
  group_by(member_casual, start_hour) %>% 
  summarise(total = n(), average = mean(minutes)) %>% 
  ggplot(aes(x = start_hour, y = average, fill = member_casual)) +geom_col(position = "dodge")

#which type is most preferred 
complete_data %>% 
  group_by(rideable_type) %>% 
  summarise(total = n()) %>% 
  ggplot(aes(x="", y = total, fill = rideable_type))+
  geom_bar(stat="identity", width = 1)+ coord_polar("y", start = 0)

complete_data %>% 
  group_by(member_casual, rideable_type) %>% 
  summarise(total = n()) %>% 
  ggplot(aes(x = rideable_type, y = total, fill = member_casual)) + geom_col()+
  scale_y_continuous(breaks = c(0,3000000), labels = c("0", "3M"))








